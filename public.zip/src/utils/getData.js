import Axios from 'axios'

export default async function getData() {

    let response = await Axios.get(" https://api.themoviedb.org/3/movie/popular?api_key=51cc7f5f459038d8f6fd27150449d6a1&language=en-US&page=1")
    .then(ress => {
        return ress
    })
    .catch(err => {
        return err
    })

  return response
}
