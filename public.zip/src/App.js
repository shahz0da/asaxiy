import './App.css';
import Footer from './Home/Footer';
import Header from './Home/Header';
import Main from './Home/Main';

function App() {
  return (
    <div className="App">
      <Header/>
      <Main/>
      <Footer/>
    </div>
  );
}

export default App;
